#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto e995022944f94d828f557238955234cb -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip --snapshot DMem_tb_behav xil_defaultlib.DMem_tb -log elaborate.log
