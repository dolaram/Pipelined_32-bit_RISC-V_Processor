#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto 6cfc93b84acf4c8dafa9da77e41c20d2 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip --snapshot ALU_Control_tb_behav xil_defaultlib.ALU_Control_tb -log elaborate.log
