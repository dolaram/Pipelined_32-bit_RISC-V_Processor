#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
echo "xvhdl -m64 --relax -prj REG_tb_vhdl.prj"
ExecStep $xv_path/bin/xvhdl -m64 --relax -prj REG_tb_vhdl.prj 2>&1 | tee -a compile.log
