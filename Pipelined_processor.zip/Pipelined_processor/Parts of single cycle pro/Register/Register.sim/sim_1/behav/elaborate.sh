#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto e67f27a409564e338a849d9d0a1d97a1 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L secureip --snapshot REG_tb_behav xil_defaultlib.REG_tb -log elaborate.log
