#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim InstMem_tb_behav -key {Behavioral:sim_1:Functional:InstMem_tb} -tclbatch InstMem_tb.tcl -log simulate.log
