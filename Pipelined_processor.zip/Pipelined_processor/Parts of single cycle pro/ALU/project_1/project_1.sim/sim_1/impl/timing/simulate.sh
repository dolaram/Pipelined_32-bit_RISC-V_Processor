#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim RAM_tb_time_impl -key {Post-Implementation:sim_1:Timing:RAM_tb} -tclbatch RAM_tb.tcl -log simulate.log
