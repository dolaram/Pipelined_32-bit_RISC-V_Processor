#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim ALU_tb_behav -key {Behavioral:sim_1:Functional:ALU_tb} -tclbatch ALU_tb.tcl -view /home/cnn/Desktop/ALU/project_1/ALU_tb_behav.wcfg -log simulate.log
