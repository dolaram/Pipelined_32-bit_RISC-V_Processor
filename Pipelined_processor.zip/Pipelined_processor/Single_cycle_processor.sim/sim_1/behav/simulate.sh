#!/bin/bash -f
xv_path="/home/cnn/Desktop/Xilinx_Vivado_SDK_2017.2_0616_1/Vivado/2017.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim CPU_tb_behav -key {Behavioral:sim_1:Functional:CPU_tb} -tclbatch CPU_tb.tcl -view /home/cnn/Desktop/Single_cycle_processor/CPU_tb_time_impl.wcfg -view /home/cnn/Desktop/Single_cycle_processor/CPU_tb_time_synth.wcfg -view /home/cnn/Desktop/Single_cycle_processor/CPU_tb_behav.wcfg -log simulate.log
